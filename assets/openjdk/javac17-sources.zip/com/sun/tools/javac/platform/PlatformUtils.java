/*
 * Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package com.sun.tools.javac.platform;

import com.sun.tools.javac.main.Arguments;
import com.sun.tools.javac.platform.PlatformProvider.PlatformNotSupported;
import java.util.Optional;
import java.util.ServiceLoader;
import java.util.stream.StreamSupport;

/** Internal utilities to work with PlatformDescriptions.
 *
 *  <p><b>This is NOT part of any supported API.
 *  If you write code that depends on this, you do so at your own risk.
 *  This code and its internal interfaces are subject to change or
 *  deletion without notice.</b>
 */
public class PlatformUtils {

    public static PlatformDescription lookupPlatformDescription(String platformString) {
        int separator = platformString.indexOf(":");
        String platformProviderName =
                separator != (-1) ? platformString.substring(0, separator) : platformString;
        String platformOptions =
                separator != (-1) ? platformString.substring(separator + 1) : "";
        Iterable<PlatformProvider> providers =
                ServiceLoader.load(PlatformProvider.class, Arguments.class.getClassLoader());

        return StreamSupport.stream(providers.spliterator(), false)
                            .filter(provider -> StreamSupport.stream(provider.getSupportedPlatformNames()
                                                                             .spliterator(),
                                                                     false)
                                                             .anyMatch(platformProviderName::equals))
                            .findFirst()
                            .flatMap(provider -> {
                                try {
                                    return Optional.of(provider.getPlatform(platformProviderName, platformOptions));
                                } catch (PlatformNotSupported pns) {
                                    return Optional.empty();
                                }
                            })
                            .orElse(null);
    }

}
